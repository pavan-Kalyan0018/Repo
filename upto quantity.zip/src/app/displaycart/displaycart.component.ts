import { Component, OnInit } from '@angular/core';
import { Cart, ViewCart } from '../cart';
import { ProductService } from '../product.service';

@Component({
  selector: 'app-displaycart',
  templateUrl: './displaycart.component.html',
  styleUrls: ['./displaycart.component.css']
})
export class DisplaycartComponent implements OnInit {


  // disCart:Cart=new Cart();
  disCart:Cart[];
  viewcart:ViewCart=new ViewCart();
  
  success:string;
  //cart: any;

  constructor(private displaycart:ProductService) { }

  ngOnInit(): void {


    this.displaycart.displayCartItems().subscribe( disCart => this.disCart=disCart);
    console.log(this.disCart);
    
  }
  decrement(cartview:ViewCart){
    cartview.quantity-=1;
    console.log(cartview.quantity,cartview.cartItemId);
    
    this.displaycart.updateCartItems(cartview).subscribe(newview => this.viewcart=newview);
 
   }
  increment(cartview:ViewCart){
  
    cartview.quantity+=1;
    console.log(cartview);
    console.log("Quantity"+cartview.quantity+"\nCartID:"+cartview.cartItemId);
    this.displaycart.updateCartItems(cartview).subscribe(newview => this.viewcart=newview);
    
  }

}
